import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("ships the VaultX product surface and removes starter copy", async () => {
  const [page, dashboard, layout, hosting, schema] = await Promise.all([
    readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/dashboard.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/layout.tsx", import.meta.url), "utf8"),
    readFile(new URL("../.openai/hosting.json", import.meta.url), "utf8"),
    readFile(new URL("../db/schema.ts", import.meta.url), "utf8"),
  ]);
  assert.match(page, /<Dashboard \/>/);
  assert.match(layout, /VaultX Ledger/);
  assert.match(dashboard, /Transaction activity/);
  assert.match(dashboard, /KYC attention/);
  assert.match(dashboard, /Search transaction ID/);
  assert.doesNotMatch(page + layout, /codex-preview|Your site is taking shape/);
  assert.deepEqual(JSON.parse(hosting), { d1: "DB", r2: "KYC_BUCKET" });
  assert.match(schema, /audit_logs/);
  assert.match(schema, /transactions_id_idx/);
});
