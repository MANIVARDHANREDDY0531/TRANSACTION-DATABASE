import { integer, real, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  email: text("email").notNull().unique(),
  displayName: text("display_name").notNull(),
  role: text("role", { enum: ["ADMIN", "COMPLIANCE", "OPERATOR", "VIEWER"] }).notNull(),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

export const clients = sqliteTable("clients", {
  id: text("id").primaryKey(),
  clientCode: text("client_code").notNull().unique(),
  fullName: text("full_name").notNull(),
  phoneCiphertext: text("phone_ciphertext").notNull(),
  emailCiphertext: text("email_ciphertext"),
  panHash: text("pan_hash").notNull(),
  riskLevel: text("risk_level", { enum: ["LOW", "MEDIUM", "HIGH"] }).notNull().default("LOW"),
  kycStatus: text("kyc_status", { enum: ["PENDING", "VERIFIED", "REJECTED", "EXPIRED"] }).notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull(),
}, (t) => [uniqueIndex("clients_pan_hash_idx").on(t.panHash)]);

export const kycDocuments = sqliteTable("kyc_documents", {
  id: text("id").primaryKey(), clientId: text("client_id").notNull().references(() => clients.id),
  kind: text("kind", { enum: ["PAN", "AADHAAR", "PASSPORT", "ADDRESS", "VIDEO"] }).notNull(),
  objectKey: text("object_key").notNull().unique(), mimeType: text("mime_type").notNull(),
  sizeBytes: integer("size_bytes").notNull(), sha256: text("sha256").notNull(),
  status: text("status", { enum: ["UPLOADED", "VERIFIED", "REJECTED"] }).notNull(),
  uploadedBy: text("uploaded_by").notNull().references(() => users.id),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

export const transactions = sqliteTable("transactions", {
  id: text("id").primaryKey(), transactionId: text("transaction_id").notNull().unique(),
  clientId: text("client_id").notNull().references(() => clients.id),
  direction: text("direction", { enum: ["BUY", "SELL"] }).notNull(),
  usdtAmount: real("usdt_amount").notNull(), inrAmountPaise: integer("inr_amount_paise").notNull(),
  ratePaise: integer("rate_paise").notNull(),
  paymentMethod: text("payment_method", { enum: ["CASH", "CDM", "UPI", "BANK_TRANSFER", "IMPS", "NEFT", "RTGS"] }).notNull(),
  paymentReference: text("payment_reference"), walletAddressCiphertext: text("wallet_address_ciphertext").notNull(),
  blockchainTxHash: text("blockchain_tx_hash"),
  status: text("status", { enum: ["DRAFT", "PROCESSING", "REVIEW", "COMPLETED", "CANCELLED"] }).notNull(),
  createdBy: text("created_by").notNull().references(() => users.id),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(), updatedAt: integer("updated_at", { mode: "timestamp" }).notNull(),
}, (t) => [uniqueIndex("transactions_id_idx").on(t.transactionId)]);

export const auditLogs = sqliteTable("audit_logs", {
  id: text("id").primaryKey(), actorId: text("actor_id").references(() => users.id),
  action: text("action").notNull(), entityType: text("entity_type").notNull(), entityId: text("entity_id").notNull(),
  beforeJson: text("before_json"), afterJson: text("after_json"), ipHash: text("ip_hash"), userAgent: text("user_agent"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});
