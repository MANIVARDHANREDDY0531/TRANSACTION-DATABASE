INSERT INTO users (id,email,display_name,role,active,created_at) VALUES
('usr_admin','admin@example.com','Nikhil Menon','ADMIN',1,unixepoch());
INSERT INTO clients (id,client_code,full_name,phone_ciphertext,email_ciphertext,pan_hash,risk_level,kyc_status,created_at,updated_at) VALUES
('cli_arjun','CL-1042','Arjun Mehta','demo:ciphertext','demo:ciphertext','demo:sha256:pan','LOW','VERIFIED',unixepoch(),unixepoch()),
('cli_meera','CL-1043','Meera Shah','demo:ciphertext','demo:ciphertext','demo:sha256:pan2','MEDIUM','VERIFIED',unixepoch(),unixepoch());
INSERT INTO transactions (id,transaction_id,client_id,direction,usdt_amount,inr_amount_paise,rate_paise,payment_method,payment_reference,wallet_address_ciphertext,blockchain_tx_hash,status,created_by,created_at,updated_at) VALUES
('txn_84291','VX-84291','cli_arjun','BUY',12450,104682500,8405,'BANK_TRANSFER','UTR-DEMO-001','demo:ciphertext','0xDEMO','COMPLETED','usr_admin',unixepoch(),unixepoch()),
('txn_84290','VX-84290','cli_meera','SELL',8200,68798000,8390,'CDM','CDM-DEMO-002','demo:ciphertext',NULL,'REVIEW','usr_admin',unixepoch(),unixepoch());
