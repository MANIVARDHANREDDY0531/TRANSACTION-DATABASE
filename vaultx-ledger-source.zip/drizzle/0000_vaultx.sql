CREATE TABLE `users` (`id` text PRIMARY KEY NOT NULL, `email` text NOT NULL UNIQUE, `display_name` text NOT NULL, `role` text NOT NULL, `active` integer DEFAULT true NOT NULL, `created_at` integer NOT NULL);
--> statement-breakpoint
CREATE TABLE `clients` (`id` text PRIMARY KEY NOT NULL, `client_code` text NOT NULL UNIQUE, `full_name` text NOT NULL, `phone_ciphertext` text NOT NULL, `email_ciphertext` text, `pan_hash` text NOT NULL, `risk_level` text DEFAULT 'LOW' NOT NULL, `kyc_status` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL);
--> statement-breakpoint
CREATE UNIQUE INDEX `clients_pan_hash_idx` ON `clients` (`pan_hash`);
--> statement-breakpoint
CREATE TABLE `kyc_documents` (`id` text PRIMARY KEY NOT NULL, `client_id` text NOT NULL REFERENCES `clients`(`id`), `kind` text NOT NULL, `object_key` text NOT NULL UNIQUE, `mime_type` text NOT NULL, `size_bytes` integer NOT NULL, `sha256` text NOT NULL, `status` text NOT NULL, `uploaded_by` text NOT NULL REFERENCES `users`(`id`), `created_at` integer NOT NULL);
--> statement-breakpoint
CREATE TABLE `transactions` (`id` text PRIMARY KEY NOT NULL, `transaction_id` text NOT NULL UNIQUE, `client_id` text NOT NULL REFERENCES `clients`(`id`), `direction` text NOT NULL, `usdt_amount` real NOT NULL, `inr_amount_paise` integer NOT NULL, `rate_paise` integer NOT NULL, `payment_method` text NOT NULL, `payment_reference` text, `wallet_address_ciphertext` text NOT NULL, `blockchain_tx_hash` text, `status` text NOT NULL, `created_by` text NOT NULL REFERENCES `users`(`id`), `created_at` integer NOT NULL, `updated_at` integer NOT NULL);
--> statement-breakpoint
CREATE UNIQUE INDEX `transactions_id_idx` ON `transactions` (`transaction_id`);
--> statement-breakpoint
CREATE INDEX `transactions_client_created_idx` ON `transactions` (`client_id`,`created_at`);
--> statement-breakpoint
CREATE TABLE `audit_logs` (`id` text PRIMARY KEY NOT NULL, `actor_id` text REFERENCES `users`(`id`), `action` text NOT NULL, `entity_type` text NOT NULL, `entity_id` text NOT NULL, `before_json` text, `after_json` text, `ip_hash` text, `user_agent` text, `created_at` integer NOT NULL);
--> statement-breakpoint
CREATE INDEX `audit_entity_created_idx` ON `audit_logs` (`entity_type`,`entity_id`,`created_at`);
