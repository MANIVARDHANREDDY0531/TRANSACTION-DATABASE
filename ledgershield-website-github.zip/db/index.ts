import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "./schema";

const globalForDb = globalThis as unknown as { ledgerPool?: Pool };
const connectionString = process.env.DATABASE_URL;
if (!connectionString && process.env.NODE_ENV === "production") throw new Error("DATABASE_URL is required");

export const pool = globalForDb.ledgerPool ?? new Pool({ connectionString: connectionString ?? "postgres://placeholder:placeholder@localhost:5432/ledgershield", max: 10, idleTimeoutMillis: 30_000, connectionTimeoutMillis: 5_000, ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : undefined });
if (process.env.NODE_ENV !== "production") globalForDb.ledgerPool = pool;
export const db = drizzle(pool, { schema });
