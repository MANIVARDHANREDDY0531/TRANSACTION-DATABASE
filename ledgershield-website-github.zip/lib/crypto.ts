import { createCipheriv, createDecipheriv, createHash, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
const scrypt = promisify(scryptCallback);

function key() { const raw = process.env.FIELD_ENCRYPTION_KEY; if (!raw) throw new Error("FIELD_ENCRYPTION_KEY is required"); const buf = Buffer.from(raw, "base64"); if (buf.length !== 32) throw new Error("FIELD_ENCRYPTION_KEY must be 32 bytes in base64"); return buf; }
export function encrypt(value: string) { const iv = randomBytes(12); const cipher = createCipheriv("aes-256-gcm", key(), iv); const body = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]); return ["v1", iv.toString("base64url"), cipher.getAuthTag().toString("base64url"), body.toString("base64url")].join("."); }
export function decrypt(value: string) { const [version, iv, tag, body] = value.split("."); if (version !== "v1") throw new Error("Unsupported ciphertext"); const decipher = createDecipheriv("aes-256-gcm", key(), Buffer.from(iv, "base64url")); decipher.setAuthTag(Buffer.from(tag, "base64url")); return Buffer.concat([decipher.update(Buffer.from(body, "base64url")), decipher.final()]).toString("utf8"); }
export function searchHash(value: string) { return createHash("sha256").update(`${process.env.SEARCH_PEPPER ?? ""}:${value.trim().toLowerCase()}`).digest("hex"); }
export function sha256(value: Buffer | string) { return createHash("sha256").update(value).digest("hex"); }
export async function hashPassword(password: string) { const salt = randomBytes(16); const derived = await scrypt(password, salt, 64) as Buffer; return `scrypt.${salt.toString("base64url")}.${derived.toString("base64url")}`; }
export async function verifyPassword(stored: string, password: string) { try { const [kind, salt, hash] = stored.split("."); if (kind !== "scrypt") return false; const expected = Buffer.from(hash, "base64url"); const actual = await scrypt(password, Buffer.from(salt, "base64url"), expected.length) as Buffer; return timingSafeEqual(expected, actual); } catch { return false; } }
