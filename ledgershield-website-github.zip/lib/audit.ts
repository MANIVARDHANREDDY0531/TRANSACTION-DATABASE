import { headers } from "next/headers";
import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import { searchHash } from "./crypto";
export async function audit(actorId: string | null, action: string, entityType: string, entityId?: string, afterHash?: string) { const h = await headers(); await db.insert(auditLogs).values({ actorId, action, entityType, entityId, afterHash, requestId: h.get("x-request-id") ?? crypto.randomUUID(), sourceIpHash: searchHash(h.get("x-forwarded-for")?.split(",")[0] ?? "unknown") }); }
