import { cookies } from "next/headers";
import { jwtVerify, SignJWT } from "jose";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";

export type Role = "admin" | "operator" | "reviewer" | "auditor";
const permissions: Record<Role, string[]> = { admin: ["*"], operator: ["clients:read","clients:write","transactions:read","transactions:write","files:read","files:write"], reviewer: ["clients:read","transactions:read","transactions:review","files:read"], auditor: ["clients:read","transactions:read","files:read","audit:read","exports:read"] };
function secret() { const value = process.env.SESSION_SECRET; if (!value || value.length < 32) throw new Error("SESSION_SECRET must be at least 32 characters"); return new TextEncoder().encode(value); }
export async function createSession(user: { id: string; email: string; role: Role }) { const token = await new SignJWT({ email: user.email, role: user.role }).setProtectedHeader({ alg: "HS256" }).setSubject(user.id).setIssuedAt().setExpirationTime("8h").sign(secret()); (await cookies()).set("ledger_session", token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/", maxAge: 8 * 60 * 60 }); }
export async function currentUser() { const token = (await cookies()).get("ledger_session")?.value; if (!token) return null; try { const { payload } = await jwtVerify(token, secret(), { algorithms: ["HS256"] }); const [user] = await db.select({ id: users.id, email: users.email, role: users.role, active: users.active }).from(users).where(eq(users.id, payload.sub!)).limit(1); return user?.active ? user : null; } catch { return null; } }
export async function requirePermission(permission: string) { const user = await currentUser(); if (!user) throw new Response("Unauthorized", { status: 401 }); const allowed = permissions[user.role].includes("*") || permissions[user.role].includes(permission); if (!allowed) throw new Response("Forbidden", { status: 403 }); return user; }
