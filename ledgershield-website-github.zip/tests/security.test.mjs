import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
const root = new URL("../", import.meta.url);
test("Railway production safeguards are configured", async () => { const [railway, docker, schema, auth, upload] = await Promise.all(["railway.json","Dockerfile","db/schema.ts","lib/auth.ts","app/api/files/route.ts"].map(p => readFile(new URL(p, root), "utf8"))); assert.match(railway, /healthcheckPath.*\/api\/health/); assert.match(railway, /db:migrate/); assert.match(docker, /USER nextjs/); assert.match(schema, /idempotencyKey/); assert.match(schema, /sha256/); assert.match(auth, /httpOnly: true/); assert.match(auth, /sameSite: "strict"/); assert.match(upload, /ServerSideEncryption/); assert.match(upload, /integrityVerifiedAt/); });
test("secrets are documented but not committed", async () => { const [example, ignore] = await Promise.all([readFile(new URL(".env.example", root), "utf8"), readFile(new URL(".gitignore", root), "utf8")]); assert.match(example, /SESSION_SECRET/); assert.match(example, /FIELD_ENCRYPTION_KEY/); assert.match(ignore, /\.env\*/); });
