# LedgerShield security and recovery baseline

## Architecture

- Private Sites access provides the sign-in gate; application roles are `admin`, `operator`, `reviewer`, and `auditor` and must be enforced in every write route.
- D1 stores relational records and encrypted sensitive fields. R2 (`VAULT`) stores KYC documents, video KYC, payment proofs, and exports. D1 stores immutable object keys, SHA-256 digests, retention dates, and ownership metadata.
- Use envelope encryption for sensitive fields and files with a managed KMS key. Rotate data-encryption keys without rewriting logical IDs. Never log plaintext KYC or wallet secrets.
- Upload flow: authorize → stream to quarantine → size/MIME/magic-byte checks → malware scan → SHA-256 digest → encrypted vault write → metadata commit. Downloads use short-lived, authorized responses with `no-store`.

## Reliability controls

- Nightly encrypted database export and object inventory to a separate account/region; 30 daily, 12 monthly, and 7 annual restore points unless legal advice requires a different policy.
- Weekly automated restore to an isolated environment, record row/object counts and checksums in `backup_checks`, and alert on any mismatch.
- Quarterly operator-led disaster recovery exercise. Recovery targets: RPO ≤ 24 hours and RTO ≤ 4 hours initially; tighten after measuring production volume.
- Soft deletion plus legal holds. A scheduled retention job purges only when `retain_until` has passed, no legal hold exists, and a two-person approval is recorded.

## Application controls

- Prepared statements, server-side validation, decimal/range checks, normalized phone/wallet identifiers, CSRF protection, restrictive CSP, rate limiting, request IDs, and idempotency keys.
- Unique database constraints prevent duplicate transaction IDs, wallet registrations, file keys, and replayed writes.
- Append-only audit events for reads of sensitive data, creates, edits, approvals, exports, downloads, permission changes, retention changes, and restore actions.
- Security alerts for repeated login failures, bulk exports, unusual KYC access, integrity mismatches, backup failures, and privilege changes.

## Setup

1. Deploy as a private Site and restrict membership to authorized staff.
2. Create users and assign least-privilege roles; require MFA through the identity provider.
3. Configure managed encryption and alert destinations outside source control.
4. Generate and apply the checked-in D1 migration, then verify indexes with representative search queries.
5. Configure malware scanning and the scheduled backup, restore-test, integrity-check, and retention jobs.
6. Run unit, authorization, validation, duplicate, upload-integrity, export, backup, and restore tests before live data is entered.
7. Complete an India-specific legal review for KYC collection, consent, DPDP obligations, record retention, and virtual digital asset compliance.

No system is bug-free. Production readiness depends on independent security review, monitored backups, successful restore tests, incident response drills, and ongoing patching.
