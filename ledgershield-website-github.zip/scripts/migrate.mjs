import { readFile } from "node:fs/promises";
import pg from "pg";
if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
const client = new pg.Client({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : undefined });
await client.connect();
try { await client.query("BEGIN"); await client.query("CREATE TABLE IF NOT EXISTS _ledger_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())"); const name = "0000_railway_postgres"; const found = await client.query("SELECT 1 FROM _ledger_migrations WHERE name = $1", [name]); if (!found.rowCount) { await client.query(await readFile(new URL("../drizzle/0000_railway_postgres.sql", import.meta.url), "utf8")); await client.query("INSERT INTO _ledger_migrations(name) VALUES ($1)", [name]); } await client.query("COMMIT"); console.log("Database migrations applied"); } catch (error) { await client.query("ROLLBACK"); throw error; } finally { await client.end(); }
