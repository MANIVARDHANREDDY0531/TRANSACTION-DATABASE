"use client";

import { useMemo, useState } from "react";

type Tx = {
  id: string; client: string; initials: string; phone: string; type: "Buy" | "Sell";
  usdt: number; inr: number; rate: number; payment: string; wallet: string;
  date: string; time: string; status: "Completed" | "Review"; proof: string;
};

const transactions: Tx[] = [
  { id: "TXN-2026-08142", client: "Arjun Mehta", initials: "AM", phone: "+91 98••• 4102", type: "Buy", usdt: 5200, inr: 473200, rate: 91, payment: "Bank transfer", wallet: "TQ7x...3mK9", date: "06 Aug 2026", time: "10:42", status: "Completed", proof: "2 files" },
  { id: "TXN-2026-08141", client: "Neha Kapoor", initials: "NK", phone: "+91 97••• 2840", type: "Sell", usdt: 1850, inr: 167425, rate: 90.5, payment: "UPI", wallet: "TK2p...8aQ4", date: "06 Aug 2026", time: "09:18", status: "Completed", proof: "3 files" },
  { id: "TXN-2026-08140", client: "Rohan Shah", initials: "RS", phone: "+91 99••• 7721", type: "Buy", usdt: 3000, inr: 273000, rate: 91, payment: "CDM", wallet: "TR9v...1nL6", date: "05 Aug 2026", time: "18:05", status: "Review", proof: "4 files" },
  { id: "TXN-2026-08139", client: "Priya Nair", initials: "PN", phone: "+91 96••• 1193", type: "Sell", usdt: 750, inr: 68062.5, rate: 90.75, payment: "Cash", wallet: "TW4c...7yE2", date: "05 Aug 2026", time: "15:31", status: "Completed", proof: "2 files" },
  { id: "TXN-2026-08138", client: "Vikram Rao", initials: "VR", phone: "+91 95••• 6038", type: "Buy", usdt: 10200, inr: 928200, rate: 91, payment: "CCW", wallet: "TB6j...4rP0", date: "05 Aug 2026", time: "12:10", status: "Completed", proof: "5 files" },
];

const clientRows = [
  ["AM", "Arjun Mehta", "14 transactions", "Verified"],
  ["NK", "Neha Kapoor", "8 transactions", "Verified"],
  ["RS", "Rohan Shah", "3 transactions", "Review"],
];

function money(value: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value);
}

export default function Home() {
  const [query, setQuery] = useState("");
  const [type, setType] = useState("All types");
  const [payment, setPayment] = useState("All payments");
  const [active, setActive] = useState("Overview");
  const [selected, setSelected] = useState<Tx | null>(null);
  const [notice, setNotice] = useState("");

  const rows = useMemo(() => transactions.filter((tx) => {
    const haystack = `${tx.id} ${tx.client} ${tx.phone} ${tx.wallet}`.toLowerCase();
    return haystack.includes(query.toLowerCase()) && (type === "All types" || tx.type === type) && (payment === "All payments" || tx.payment === payment);
  }), [query, type, payment]);

  function exportCsv() {
    const csv = ["Transaction ID,Client,Type,USDT,INR,Rate,Payment,Wallet,Date,Status", ...rows.map(t => [t.id,t.client,t.type,t.usdt,t.inr,t.rate,t.payment,t.wallet,t.date,t.status].join(","))].join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a"); a.href = url; a.download = "ledgershield-transactions.csv"; a.click(); URL.revokeObjectURL(url);
    setNotice(`${rows.length} transactions exported with masked sensitive fields.`);
  }

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">L</span><span>LedgerShield</span></div>
        <nav aria-label="Primary navigation">
          {["Overview", "Transactions", "Clients", "KYC vault", "Audit log"].map((item, i) => (
            <button key={item} className={active === item ? "nav-item active" : "nav-item"} onClick={() => setActive(item)}><span className="nav-icon">{["⌂","↔","◎","▣","≡"][i]}</span>{item}{item === "KYC vault" && <span className="count">3</span>}</button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <button className="nav-item" onClick={() => setNotice("Settings are restricted to administrators.")}><span className="nav-icon">⚙</span>Settings</button>
          <div className="security-card"><div className="security-top"><span className="pulse" />Systems healthy</div><p>Backup completed 14 min ago</p><div className="tiny-bar"><i /></div><small>Integrity checks passed</small></div>
          <div className="user-card"><span className="avatar">AK</span><div><strong>Admin</strong><span>Operations</span></div><button aria-label="Open user menu">•••</button></div>
        </div>
      </aside>

      <section className="workspace">
        <header className="topbar">
          <div><span className="eyebrow">PRIVATE OPERATIONS</span><h1>{active}</h1></div>
          <div className="top-actions"><span className="last-sync"><i /> Live · Synced now</span><button className="icon-button" aria-label="Notifications">◌<b /></button><button className="primary" onClick={() => setNotice("New transaction form opened — duplicate checks enabled.")}>＋ New transaction</button></div>
        </header>

        {active === "Overview" && <>
          <section className="hero-row">
            <div><p className="kicker">Thursday, 06 August</p><h2>Your operation is <em>fully accounted for.</em></h2><p className="subcopy">Every rupee, every token, every verification — traceable from one protected ledger.</p></div>
            <div className="risk-card"><div><span>Risk watch</span><strong>1 item</strong></div><p>Rohan Shah’s CDM proof needs a second review.</p><button onClick={() => { setActive("KYC vault"); setNotice("Review queue filtered to the flagged record."); }}>Review now →</button></div>
          </section>

          <section className="metrics">
            <article><span className="metric-label">TODAY’S VOLUME</span><strong>₹19.1L</strong><p><b className="up">↑ 12.4%</b> vs. yesterday</p><i className="spark s1" /></article>
            <article><span className="metric-label">USDT MOVED</span><strong>21,000</strong><p>8 transactions today</p><i className="spark s2" /></article>
            <article><span className="metric-label">ACTIVE CLIENTS</span><strong>142</strong><p><b className="up">+5</b> this month</p><div className="avatar-stack"><span>AM</span><span>NK</span><span>RS</span><span>+9</span></div></article>
            <article><span className="metric-label">KYC COVERAGE</span><strong>97.9%</strong><p>3 reviews pending</p><div className="progress"><i /></div></article>
          </section>
        </>}

        {active === "Clients" ? <section className="panel clients-panel"><div className="panel-head"><div><h3>Client profiles</h3><p>Identity records and lifetime transaction history</p></div><button className="primary" onClick={() => setNotice("New client onboarding opened with KYC consent capture.")}>＋ Add client</button></div>{clientRows.map(c => <button className="client-row" key={c[1]} onClick={() => { setActive("Transactions"); setQuery(c[1]); }}><span className="avatar light">{c[0]}</span><span><strong>{c[1]}</strong><small>{c[2]}</small></span><b className={c[3] === "Review" ? "status review" : "status"}>{c[3]}</b><i>→</i></button>)}</section>
        : active === "KYC vault" ? <section className="panel vault"><div className="panel-head"><div><h3>KYC vault</h3><p>Encrypted documents, consent records and video verification</p></div><span className="shield-label">SHA-256 integrity protected</span></div><div className="vault-grid"><article><span>▣</span><strong>412</strong><p>Protected files</p><small>All hashes verified</small></article><article><span>◉</span><strong>138</strong><p>Video KYC records</p><small>Encrypted at rest</small></article><article><span>!</span><strong>3</strong><p>Pending reviews</p><small>One due today</small></article></div><div className="control-list"><div><i className="ok">✓</i><span><strong>File integrity check</strong><small>Completed today at 04:10 · 0 mismatches</small></span><b>Passed</b></div><div><i className="ok">✓</i><span><strong>Retention policy</strong><small>7 years for transaction proofs · configurable by admin</small></span><b>Active</b></div><div><i className="warn">!</i><span><strong>Manual review queue</strong><small>Rohan Shah · CDM deposit proof</small></span><button onClick={() => setNotice("Review assigned to your secure queue.")}>Open review</button></div></div></section>
        : active === "Audit log" ? <section className="panel"><div className="panel-head"><div><h3>Immutable audit trail</h3><p>Security-relevant actions with actor, time and source</p></div><span className="shield-label">Append-only</span></div><div className="audit-list">{[["10:42","Transaction TXN-2026-08142 created","Admin · 10.24.8.14"],["10:40","KYC document checksum verified","System · integrity worker"],["09:19","Transaction TXN-2026-08141 approved","Reviewer · 10.24.8.22"],["04:10","Automated backup completed","System · encrypted replica"]].map(a => <div key={a[0]+a[1]}><time>{a[0]}</time><span><strong>{a[1]}</strong><small>{a[2]}</small></span><b>Recorded</b></div>)}</div></section>
        : <section className="panel transactions-panel">
          <div className="panel-head"><div><h3>{active === "Transactions" ? "Transaction register" : "Recent transactions"}</h3><p>Search and verify every movement</p></div><button className="export" onClick={exportCsv}>⇩ Export CSV</button></div>
          <div className="filters"><label className="search"><span>⌕</span><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search ID, client, phone or wallet…" aria-label="Search transactions" /></label><select value={type} onChange={e => setType(e.target.value)} aria-label="Filter transaction type"><option>All types</option><option>Buy</option><option>Sell</option></select><select value={payment} onChange={e => setPayment(e.target.value)} aria-label="Filter payment mode"><option>All payments</option><option>Bank transfer</option><option>UPI</option><option>Cash</option><option>CDM</option><option>CCW</option></select><button className="date-filter">▦ Date range</button></div>
          <div className="table-wrap"><table><thead><tr><th>TRANSACTION</th><th>CLIENT</th><th>TYPE</th><th>AMOUNT</th><th>PAYMENT</th><th>DATE & TIME</th><th>STATUS</th><th /></tr></thead><tbody>{rows.map(tx => <tr key={tx.id} onClick={() => setSelected(tx)}><td><strong>{tx.id}</strong><small>{tx.wallet}</small></td><td><span className="client-cell"><i>{tx.initials}</i><span><strong>{tx.client}</strong><small>{tx.phone}</small></span></span></td><td><b className={tx.type === "Buy" ? "type buy" : "type sell"}>{tx.type}</b></td><td><strong>{tx.usdt.toLocaleString("en-IN")} USDT</strong><small>{money(tx.inr)} · ₹{tx.rate}</small></td><td><strong>{tx.payment}</strong><small>{tx.proof} attached</small></td><td><strong>{tx.date}</strong><small>{tx.time} IST</small></td><td><b className={tx.status === "Review" ? "status review" : "status"}>{tx.status}</b></td><td>›</td></tr>)}</tbody></table>{rows.length === 0 && <div className="empty">No matching transactions. Try clearing a filter.</div>}</div>
          <div className="table-foot"><span>Showing {rows.length} of 8,421 protected records</span><div><button disabled>‹</button><button className="page">1</button><button>2</button><button>3</button><button>›</button></div></div>
        </section>}

        <footer><span><i /> Encrypted in transit and at rest</span><span>Last backup: today, 10:28 · Restore test: 03 Aug, passed</span><span>Retention: 7 years</span></footer>
      </section>

      {notice && <div className="toast" role="status"><span>✓</span>{notice}<button onClick={() => setNotice("")}>×</button></div>}
      {selected && <div className="modal-backdrop" onMouseDown={() => setSelected(null)}><article className="detail-modal" onMouseDown={e => e.stopPropagation()}><div className="modal-head"><div><span className="eyebrow">TRANSACTION RECORD</span><h2>{selected.id}</h2></div><button onClick={() => setSelected(null)} aria-label="Close">×</button></div><div className="detail-status"><b className={selected.status === "Review" ? "status review" : "status"}>{selected.status}</b><span>Integrity hash verified</span></div><div className="detail-grid"><div><small>CLIENT</small><strong>{selected.client}</strong><span>{selected.phone}</span></div><div><small>DIRECTION</small><strong>{selected.type} USDT</strong><span>{selected.usdt.toLocaleString("en-IN")} USDT</span></div><div><small>INR SETTLEMENT</small><strong>{money(selected.inr)}</strong><span>Rate ₹{selected.rate}/USDT</span></div><div><small>PAYMENT MODE</small><strong>{selected.payment}</strong><span>{selected.proof} verified</span></div><div className="wide"><small>WALLET</small><strong className="mono">{selected.wallet}••••••••••••verified</strong><span>TRON · Address screened at capture</span></div><div><small>RECORDED</small><strong>{selected.date}</strong><span>{selected.time} IST</span></div></div><div className="evidence"><h3>Evidence & controls</h3><div><span>▣ Payment proof</span><b>Hash verified</b></div><div><span>◉ Client KYC & consent</span><b>Linked</b></div><div><span>≡ Audit trail</span><b>4 events</b></div></div><button className="primary full" onClick={() => setNotice("Detailed record prepared for secure print view.")}>Open full record</button></article></div>}
    </main>
  );
}
