import { PutObjectCommand } from "@aws-sdk/client-s3";
import { z } from "zod";
import { db } from "@/db";
import { files } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { bucketName, s3 } from "@/lib/bucket";
import { encrypt, sha256 } from "@/lib/crypto";
const meta = z.object({ clientId: z.uuid().optional(), transactionId: z.uuid().optional(), category: z.enum(["identity","address","video_kyc","payment_proof","wallet_proof","other"]), retainUntil: z.iso.datetime() }).refine(v => v.clientId || v.transactionId, "clientId or transactionId is required");
const allowed = new Set(["application/pdf","image/jpeg","image/png","video/mp4","video/webm"]);
export async function POST(request: Request) { const user = await requirePermission("files:write"); const form = await request.formData(); const file = form.get("file"); const parsed = meta.safeParse(JSON.parse(String(form.get("metadata") ?? "{}"))); if (!(file instanceof File) || !parsed.success) return Response.json({ error: "Invalid file or metadata" }, { status: 400 }); const max = parsed.data.category === "video_kyc" ? 250 * 1024 * 1024 : 20 * 1024 * 1024; if (!allowed.has(file.type) || file.size <= 0 || file.size > max) return Response.json({ error: "Unsupported file type or size" }, { status: 415 }); const bytes = Buffer.from(await file.arrayBuffer()); const digest = sha256(bytes); const objectKey = `${parsed.data.clientId ?? "transactions"}/${new Date().getUTCFullYear()}/${crypto.randomUUID()}`; await s3.send(new PutObjectCommand({ Bucket: bucketName, Key: objectKey, Body: bytes, ContentType: file.type, Metadata: { sha256: digest }, ServerSideEncryption: "AES256" })); const [record] = await db.insert(files).values({ ...parsed.data, objectKey, originalNameEncrypted: encrypt(file.name), mimeType: file.type, bytes: file.size, sha256: digest, uploadedBy: user.id, retainUntil: new Date(parsed.data.retainUntil), integrityVerifiedAt: new Date() }).returning({ id: files.id, sha256: files.sha256 }); await audit(user.id, "file.upload", "file", record.id, digest); return Response.json({ file: record }, { status: 201 }); }
