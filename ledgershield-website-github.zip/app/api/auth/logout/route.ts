import { cookies } from "next/headers";
export async function POST() { (await cookies()).delete("ledger_session"); return new Response(null, { status: 204 }); }
