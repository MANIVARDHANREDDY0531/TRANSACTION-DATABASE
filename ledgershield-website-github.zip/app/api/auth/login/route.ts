import * as OTPAuth from "otpauth";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { decrypt, verifyPassword } from "@/lib/crypto";
const schema = z.object({ email: z.email(), password: z.string().min(12), totp: z.string().regex(/^\d{6}$/) });
export async function POST(request: Request) { const parsed = schema.safeParse(await request.json().catch(() => null)); if (!parsed.success) return Response.json({ error: "Invalid credentials" }, { status: 400 }); const [user] = await db.select().from(users).where(eq(users.email, parsed.data.email.toLowerCase())).limit(1); const passwordOk = user?.active && await verifyPassword(user.passwordHash, parsed.data.password); if (!passwordOk || !user.mfaSecretEncrypted) { await audit(user?.id ?? null, "auth.login_failed", "user", user?.id); return Response.json({ error: "Invalid credentials" }, { status: 401 }); } const totp = new OTPAuth.TOTP({ issuer: "LedgerShield", label: user.email, algorithm: "SHA1", digits: 6, period: 30, secret: OTPAuth.Secret.fromBase32(decrypt(user.mfaSecretEncrypted)) }); if (totp.validate({ token: parsed.data.totp, window: 1 }) === null) { await audit(user.id, "auth.mfa_failed", "user", user.id); return Response.json({ error: "Invalid credentials" }, { status: 401 }); } await createSession({ id: user.id, email: user.email, role: user.role }); await audit(user.id, "auth.login", "user", user.id); return Response.json({ user: { email: user.email, role: user.role } }); }
