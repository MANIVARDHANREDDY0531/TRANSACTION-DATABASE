import { pool } from "@/db";
export const dynamic = "force-dynamic";
export async function GET() { try { await pool.query("select 1"); return Response.json({ status: "ok", database: "connected", time: new Date().toISOString() }); } catch { return Response.json({ status: "unhealthy", database: "unavailable" }, { status: 503 }); } }
