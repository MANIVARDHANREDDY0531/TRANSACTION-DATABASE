import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "LedgerShield — Secure USDT Operations",
  description: "Private USDT transaction, client KYC and evidence operations ledger.",
  icons: { icon: "/favicon.svg" },
  openGraph: { title: "LedgerShield", description: "Secure USDT operations, verified.", images: [{ url: "/og.png", width: 1200, height: 630 }] },
  twitter: { card: "summary_large_image", title: "LedgerShield", description: "Secure USDT operations, verified.", images: ["/og.png"] },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
