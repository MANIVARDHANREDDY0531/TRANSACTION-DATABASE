import { redirect } from "next/navigation";
import Dashboard from "./Dashboard";
import { currentUser } from "@/lib/auth";
export const dynamic = "force-dynamic";
export default async function Home() { const user = await currentUser(); if (!user) redirect("/login"); return <Dashboard />; }
